/*:
 # Swift Language Tutorial
 * This playground covers all the key concepts of swift language
 * This playground is still being updated, if you find something you can add on your own and merge into my rep
 * I will try to update with every concept.
 */
//integar max size
print("Int32 Min = \(Int32.min) Int32 Max = \(Int32.max)")

//MARK: Swift Tuples

let myTuple = (12.3, "This is the tuple")

let stringFromTuple = myTuple.1

let anotherTuple = (count: 10, length: 3.2, message: "this is advance form of tuple")

let tupleMessage = anotherTuple.message

//MARK: Optional Type in swift

var index: Int?

if index != nil {
    print("This contain some value")
} else {
    print("This is nil")
}

index = 2

var planetArr = ["mars", "earth", "venus"]

// force unwrapping the optional
if index != nil {
    print(planetArr[index!])
} else {
    print("index is nil")
}

//optional binding
if let someVal = index {
    print("index contain some val which is \(someVal)")
} else {
    print("SomeVal is nil")
}

//implicit unwrapped
var someInt: Int!

someInt = 2

print(someInt)

//MARK: Ternary Operator

var x: Int?
x = 10
let y = 20

print("the greater value is \(x! > y ? x : y)")

//MARK: The Guard Statement

for index in 1...10 {
    
//    guard let number = x, number < 5 else {
//        print("number is not greater")
//        return
//    }
    
}

//MARK: Range Matching in switch

let temperature = 20

switch temperature {
case 1...10:
    print("Take umbrella")
case 10...20:
    print("Wear Glasses")
default:
    print("Stay at home!")
}

//switch with WHERE condition

switch temperature {
case 1...10 where temperature % 2 == 0:
    print("Cold and Even")
case 10...20 where temperature % 2 == 0:
    print("Hot and Even")
default:
    print("Odd and not applicable")
}

/*:
 # Functions and Methods and Closures
 */

//MARK: Functions

//declaration
/*
 func <function name> (<parametere name>: <parameter type>, <parametere name>: <parameter type>, ...) -> <return type> {
    //function code
 }
 */

//calling a func
/*
 <func name>(<arg1>, <arg2>, ...)
 */

func helloFunc(){
    print("Simplest form of function")
}

// if the result returned by function is not used. The caller can be replaced by '_'

func buildMessageFor(_ name: String, _ count: Int) -> String {
    return("\(name) has \(count) customers")
}

//let message = buildMessageFor(name: "john", count: 100)

let anotherMessage = buildMessageFor("eddy", 50)

//default type of parameter

func message(userName name: String = "Customer", Count count: Int) -> String {
    return("\(name), Your number is \(count)")
}

let numberCount = message(Count: 10)

//Multiple return results from one function

func converter(_ length: Float) -> (yards: Float, centimeter: Float, meters: Float) {
    
    let yards = length * 0.0277
    let centimeteres = length * 0.0277
    let meters = length * 0.0277
    
    return(yards,centimeteres,meters) //in the form of tuple
}

let length = converter(10)

print(length.meters)

//MARK: Variadic Parameters

func displayString(_ strings: String...) {
    for string in strings {
        print(string)
    }
}

displayString("one", "two", "three")

//MARK: IN-OUT parameter types

func doubleValue(_ value: inout Int) -> Int {
    value += value
    return(value)
}

var myValue = 10 //we need to declare the variable first to pass it as arguement to create shadow of

print("doubleValue calls returns the \(doubleValue(&myValue))")

//MARK: Functions as parameters

func inchesToFeet(_ inches: Float) -> Float {
    return inches * 0.0277
}

let toFeet = inchesToFeet //functions are assigned to a variable which will later used instead of original func name

toFeet(1)

/*:
 # Closures Expressions
 */

//simplest form of closures

let sayHello = { print("Hello Closures") }

sayHello

//General form of closures
/*
 { ( <para name>: <para type>, <para name>: <para type>, ... ) -> <return type> in
 
    //closure expression code here
 
 }
 */

//simple closure expression

let multiply = { (_ val1: Int, _ val2: Int) -> Int in
    
    return val1 * val2
    
}

multiply(2,2) //the variable name will be used to execute the closure block

//the use case scenarios of closures are in GCD where only completion block and result is needed to assign it to the any constant

/*:
 # Classes and Basic OOP
 */

//objects in OOP consists of data variable called Properties
//Functions in class called Methods as mentioned above in Function Section.

//General Syntax for any class
/*
 class NewClassName: ParentClass {
 
    //Properties
    //Instance Methods
    //Type Methods
 
 }
 */

//Example of class and OOP
//Data Encapsulation is that data is encapsulated within the class using variables and should be accessed using Class Methods

class BankAccount {
    
    //declaration of instances/properties
    var accountBalance: Float = 0
    var accountNumber: Int = 0
    
    /*
     There are two types of methods
     Type Method operates at class level to create new instances
     Instance method operates only on the instances of class
     */
    
    //init method will run on the time of initialization
    init(number: Int, balance: Float) {
        accountBalance = balance
        accountNumber = number
    }
    
    //computed properties
    var balanceLessFees: Float {
        get {
            return accountBalance - 100
        }
        
        set(newBalance) {
            accountBalance = newBalance - 100
        }
    }
    //instance method
    func displayBalance(){
        print("The account number is \(accountNumber)")
        print("The current balance is \(accountBalance)")
    }
    
    //Type method
    class func getMaxBalance() -> Float {
        return 100000.00
    }
    
}

//declaring the object of the class
var account1: BankAccount = BankAccount(number: 123, balance: 12345)

//using Dot Notation
var accountBalance = account1.accountBalance


/*:
 # Subclassing and Extensions
 */

//Swift Inheritance Example
//we are creating child class which will derive all of RootClass properties in its own class and extend it, if required.
class SavingAccounts: BankAccount {
    
    var interestRate: Float = 0.0
    
    //extending the functionality of class
    func calculateInterest() -> Float {
        return interestRate * accountBalance //accessing the accountBalance variable from base Class
    }
    
    //overriding the method means conforming to the two steps
    //step 1: it should take same number of parameters
    //step 2: it should have same return type
    override func displayBalance() {
        //using super to display the previous class print statements as well
        super.displayBalance()
        print("You current balance after interest rate is: \(interestRate)")
    }
    
    //using initializer in the sub class
    init(number: Int, balance: Float, rate: Float) {
        //we have defined our own initializer above but we will derive the Parent Class init to use that
        super.init(number: number, balance: balance)
        interestRate = rate
    }
    
}

var newSavingAccount: SavingAccounts = SavingAccounts(number: 1234, balance: 12345, rate: 2.2) //declaring object from the child class

print(newSavingAccount.calculateInterest())

//MARK: Swift Class Extensions

//Swift class Extensions are use to extend the properties and functionalities of any class without creating subclass

//general syntax
/*
 extension ClassName {
    //new features here
 }
 */

extension Double {
    var squared: Double {
        return self * self //returning the square of a variable
    }
    
    var cubed: Double {
        return self * self * self //returning the cube of number
    }
}

let anotherMyValue: Double = 3.0
print(anotherMyValue.squared) //using the squared value here we derived in the Double Extension

/*:
 # Arrays and Dictionaries
 */

//concept of Mutable and Immutable Collections
/*
 The mutable collections can be changed after initializing them (var)
 The immutable collections CANNOT be change after initialization (let)
 */

//general syntax of array
/*
 var variableName: [type] = [value1, value2, ...]
 */

var tree = ["plum", "Oak", "yew"] //mutable array //it is type infered array

let treeArray: [String] = ["plum", "Pint", "Yew"] //immutable and type annotation array

print(tree[1]) //accessing the specifc index element

tree.append("Maple") //appending element to mutable array

//iterating through the array

for specificTree in tree {
    print(specificTree)
}

let mixedArray: [Any] = ["Moazzam", 12, 12.0] //this is the mixed array which is type of ANY

for element in mixedArray {
    //print(element as! Int * 2)
}

//MARK: Dictionaries

//Dictionaries consist of Key Value pair.
//general syntax of dictionaries
/*
 var variableName: [key Type: value Type] = [key1: value1, key2: value2, ...]
 */

var bookDict: [String: String] = ["100-100": "Wind in the willows",
                "100-101": "Tale of two cities"]

//There is a zip function for dictionaries which allows to create the dictionaries from two sequenced variables
let isbnNumber: [String] = ["100", "101", "102"]
let title: [String] = ["Book1", "Book2", "Book3"]

let dict = Dictionary(uniqueKeysWithValues: zip(isbnNumber, title))

//iterating through the dictionaries

for (bookId, title) in dict {
    print("Book ISBN: \(bookId), Book Name: \(title)")
}


/*:
 # Swift Error Handling
 * Throwing Methods and Functions
 * Error Types
 * The guard and defer statement
 * Do Catch Statements
 */

/*
    consider an example in which you are trying to make an app, which is capable of sending file to another location.
    the file transfer might fail and you have to make your code rubust and do some error handling before it jams the whole application
*/

//declare error types first using enumerations
//naming convention for case will be noun, which caused error
enum ErrorType: Error { //type annotation is specifically error because it has Throw properties binded.
    case noConnection
    case lowBandWidth
    case fileNotFound
}

let connectionEstablished = true
let bandwidth = 30.00
let fileFound = false

//the method of func that can throw an error, is declared as below

func fileTransfer() throws { //throws keyword represent the error handling feature
    
    //the constants/variable will be used with Guard statement, so that in result of else the error can be thrown
    guard connectionEstablished else {
        throw ErrorType.noConnection
    }
    
    guard bandwidth > 30 else { //it always has to be in true/false scenario
        throw ErrorType.lowBandWidth
    }
    
    guard fileFound else {
        throw ErrorType.fileNotFound
    }
    
}

//the function/method which is declared as Error handling will be called using Try Catch statements
func sendFile() -> String {
    
    defer { //the defer statement is used to take precautions before returning an error.
        //removeTempFile()
        //closeConnection()
    }
    
    do {
        try fileTransfer()
    } catch ErrorType.fileNotFound {
        print("File could not be loaded")
    } catch ErrorType.lowBandWidth {
        print("Slow Internet Connection")
    } catch ErrorType.noConnection {
        print("Connection could not be established")
    } catch {
        print("Unknown Error")
    }
    
    return("Transferred Successfully!")
}

/*:
 # This is the example of Live View in Playground
 */
import UIKit
import PlaygroundSupport

let container = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 400))
container.backgroundColor = UIColor.white

PlaygroundPage.current.liveView = container

let square = UIView(frame: CGRect(x: 50, y: 50, width: 200, height: 200))
square.backgroundColor = UIColor.black

let lineInsideSquare = UIView(frame: CGRect(x: 100, y: 50, width: 10, height: 50))
lineInsideSquare.backgroundColor = UIColor.red

container.addSubview(square) //adding the subview to container view
square.addSubview(lineInsideSquare)

UIView.animate(withDuration: 2.0) {
    square.backgroundColor = UIColor.blue
    let rotation = CGAffineTransform(rotationAngle: 3.14)
    square.transform = rotation
}
